<?php
namespace TypechoPlugin\AAEditor;
class Label extends \Typecho\Widget\Helper\Layout
{
    public function __construct($html)
    {
        $this->html($html);
        $this->start();
        $this->end();
    }

    public function start()
    {
    }

    public function end()
    {
    }
}
